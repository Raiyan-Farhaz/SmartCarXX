public class Customer extends Person{
    private int custNo;

    // Constructor to initialize Customer details
    public Customer(String firstName, String lastName, String email, String address, int custNo) {
        super(firstName, lastName, email, address);  // Calling the parent class (Person) constructor
        this.custNo = custNo;
    }

    public int getCustNo() {
        return custNo;
    }
    public void setCustNo(int custNo) {
        this.custNo = custNo;
    }

    @Override
    public String toString() {
        return super.toString() + String.format(", Customer Number: %d", custNo);
    }
}
