public class Employee extends Person{
    private int empNo;

    // Constructor to initialize Employee details
    public Employee(String firstName, String lastName, String email, String address, int empNo) {
        super(firstName, lastName, email, address);  // Calling the parent class (Person) constructor
        this.empNo = empNo;
    }

    public int getEmpNo() {
        return empNo;
    }

    public void setEmpNo(int empNo) {
        this.empNo = empNo;
    }

    @Override
    public String toString() {
        return super.toString() + String.format(", Employee Number: %d", empNo);
    }
}
